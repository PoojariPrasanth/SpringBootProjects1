package com.example.SecurityUsingMySQLUsingGrok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityUsingMySqlUsingGrokApplicationTests {

	@Test
	void contextLoads() {
	}

}
